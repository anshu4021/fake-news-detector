import { NewsAnalyzer } from "@/components/news-analyzer"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Fake News Detector</h1>
          <p className="text-lg text-muted-foreground">
            Analyze news articles to identify potential misinformation using AI
          </p>
        </div>
        <NewsAnalyzer />
      </div>
    </div>
  )
}
