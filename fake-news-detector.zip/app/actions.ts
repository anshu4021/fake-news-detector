"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function analyzeNews(content: string, type: "text" | "url") {
  try {
    // If URL is provided, fetch the content
    let textToAnalyze = content

    if (type === "url") {
      try {
        const response = await fetch(content)
        if (!response.ok) {
          throw new Error("Failed to fetch article from URL")
        }
        const html = await response.text()

        // Very basic HTML text extraction (in a real app, use a proper HTML parser)
        textToAnalyze = html
          .replace(/<[^>]*>/g, " ")
          .replace(/\s+/g, " ")
          .trim()
      } catch (error) {
        throw new Error("Could not retrieve content from the provided URL")
      }
    }

    // Truncate if too long
    if (textToAnalyze.length > 8000) {
      textToAnalyze = textToAnalyze.substring(0, 8000) + "..."
    }

    const prompt = `
      Analyze the following news content for potential misinformation or fake news indicators.
      Provide a structured analysis with the following components:
      1. Credibility Score (1-10)
      2. Bias Level (description)
      3. Emotional Language (description)
      4. Sources Quality (description)
      5. Factual Accuracy (description)
      6. Brief Summary of Analysis
      7. Final Verdict (choose one: reliable, questionable, unreliable)

      Format your response as a JSON object with these keys: credibilityScore, biasLevel, emotionalLanguage, sourcesQuality, factualAccuracy, summary, verdict.

      News Content:
      ${textToAnalyze}
    `

    const { text } = await generateText({
      model: openai("gpt-4o"),
      prompt,
      temperature: 0.3,
      maxTokens: 1000,
    })

    // Parse the JSON response
    try {
      return JSON.parse(text)
    } catch (error) {
      console.error("Failed to parse AI response as JSON:", text)
      throw new Error("Failed to analyze the content. Please try again.")
    }
  } catch (error) {
    console.error("Error in analyzeNews:", error)
    throw error
  }
}
