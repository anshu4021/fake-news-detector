"use client"

import { useState } from "react"
import { AlertCircle, CheckCircle, Info, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { analyzeNews } from "@/app/actions"

type AnalysisResult = {
  credibilityScore: number
  biasLevel: string
  emotionalLanguage: string
  sourcesQuality: string
  factualAccuracy: string
  summary: string
  verdict: "reliable" | "questionable" | "unreliable"
}

export function NewsAnalyzer() {
  const [isLoading, setIsLoading] = useState(false)
  const [newsText, setNewsText] = useState("")
  const [newsUrl, setNewsUrl] = useState("")
  const [activeTab, setActiveTab] = useState("text")
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleAnalyze = async () => {
    setIsLoading(true)
    setError(null)
    setResult(null)

    try {
      const content = activeTab === "text" ? newsText : newsUrl
      const type = activeTab === "text" ? "text" : "url"

      if (!content.trim()) {
        throw new Error("Please enter some content to analyze")
      }

      const analysisResult = await analyzeNews(content, type)
      setResult(analysisResult)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const getVerdictColor = (verdict?: string) => {
    switch (verdict) {
      case "reliable":
        return "text-green-600"
      case "questionable":
        return "text-amber-600"
      case "unreliable":
        return "text-red-600"
      default:
        return "text-muted-foreground"
    }
  }

  const getVerdictIcon = (verdict?: string) => {
    switch (verdict) {
      case "reliable":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "questionable":
        return <Info className="h-5 w-5 text-amber-600" />
      case "unreliable":
        return <AlertCircle className="h-5 w-5 text-red-600" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="text" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="text">Paste Article Text</TabsTrigger>
          <TabsTrigger value="url">Enter Article URL</TabsTrigger>
        </TabsList>
        <TabsContent value="text" className="mt-4">
          <Textarea
            placeholder="Paste the news article text here..."
            className="min-h-[200px]"
            value={newsText}
            onChange={(e) => setNewsText(e.target.value)}
          />
        </TabsContent>
        <TabsContent value="url" className="mt-4">
          <Input
            type="url"
            placeholder="https://example.com/news-article"
            value={newsUrl}
            onChange={(e) => setNewsUrl(e.target.value)}
          />
        </TabsContent>
      </Tabs>

      <Button onClick={handleAnalyze} disabled={isLoading} className="w-full">
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Analyzing...
          </>
        ) : (
          "Analyze Content"
        )}
      </Button>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {result && (
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              {getVerdictIcon(result.verdict)}
              <CardTitle className={getVerdictColor(result.verdict)}>
                {result.verdict === "reliable"
                  ? "Likely Reliable"
                  : result.verdict === "questionable"
                    ? "Questionable Content"
                    : "Potentially Unreliable"}
              </CardTitle>
            </div>
            <CardDescription>Credibility Score: {result.credibilityScore}/10</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">{result.summary}</p>

            <div className="grid gap-3 pt-3">
              <div className="grid grid-cols-[25px_1fr] items-start">
                <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-blue-500" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Bias Level</p>
                  <p className="text-sm text-muted-foreground">{result.biasLevel}</p>
                </div>
              </div>
              <div className="grid grid-cols-[25px_1fr] items-start">
                <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-blue-500" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Emotional Language</p>
                  <p className="text-sm text-muted-foreground">{result.emotionalLanguage}</p>
                </div>
              </div>
              <div className="grid grid-cols-[25px_1fr] items-start">
                <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-blue-500" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Sources Quality</p>
                  <p className="text-sm text-muted-foreground">{result.sourcesQuality}</p>
                </div>
              </div>
              <div className="grid grid-cols-[25px_1fr] items-start">
                <span className="flex h-2 w-2 translate-y-1.5 rounded-full bg-blue-500" />
                <div className="space-y-1">
                  <p className="text-sm font-medium">Factual Accuracy</p>
                  <p className="text-sm text-muted-foreground">{result.factualAccuracy}</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-xs text-muted-foreground">
              This analysis is provided as a guide only. Always verify information from multiple reliable sources.
            </p>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}
